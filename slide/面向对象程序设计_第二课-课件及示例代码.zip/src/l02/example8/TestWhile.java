package l02.example8;

public class TestWhile {
	public static void main(String args[]) {

		int count = 1;

		while (count <= 100) {

			System.out.println(count + " Welcome to Java!");

			count++;

		}

	}
}
