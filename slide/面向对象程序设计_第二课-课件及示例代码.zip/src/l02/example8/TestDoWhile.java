package l02.example8;

public class TestDoWhile {
	public static void main(String args[]) {

		int count = 0;

		do {
			System.out.println(count + " Welcome to Java!");

			count++;
			
		} while (count < 100);
	}
}
