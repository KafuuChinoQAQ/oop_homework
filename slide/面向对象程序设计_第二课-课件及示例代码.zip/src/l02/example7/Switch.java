package l02.example7;

public class Switch {
	public static void main(String args[]) {
		int i = 1;
		switch (i) {
		case 0:
			System.out.println("case 0, i = " + i);
			break;
		case 1:
			System.out.println("case 1, i = " + i);
			break;
		case 2:
			System.out.println("case 2, i = " + i);
			break;
		case 3:
			System.out.println("case 3, i = " + i);
			break;
		default:
			System.out.println("default, i = " + i);
		}
	}
}
