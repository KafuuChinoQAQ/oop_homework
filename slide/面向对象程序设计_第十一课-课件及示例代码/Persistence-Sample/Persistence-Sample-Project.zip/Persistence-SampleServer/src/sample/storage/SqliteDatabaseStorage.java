package sample.storage;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sample.api.model.Player;

public class SqliteDatabaseStorage implements Storage {
	private static Logger LOGGER = LoggerFactory.getLogger(SqliteDatabaseStorage.class);
	private String location;
	private String connectionString;

	private String getLocation() {
		return location;
	}

	private void setLocation(String location) {
		this.location = location;
	}

	private String getConnectionString() {
		return connectionString;
	}

	private void setConnectionString(String connectionString) {
		this.connectionString = connectionString;
	}

	public SqliteDatabaseStorage() {
		try {
			Class.forName("org.sqlite.JDBC");
			this.setLocation((FilePath.getRootPath() + File.separator + "player.sqlite").replace('\\', '/'));
			this.setConnectionString("jdbc:sqlite:" + this.getLocation());
			LOGGER.info("Current file location is " + this.getLocation());
			File file = new File(this.getLocation());
			if (!file.exists()) {
				Connection connection = DriverManager.getConnection(this.getConnectionString());
				Statement statement = connection.createStatement();
				String sql = "CREATE TABLE \"player\" " + "(\"id\" INT PRIMARY KEY NOT NULL,"
						+ " \"nickName\" VARCHAR(100) NOT NULL, " + " \"experience\" INT NOT NULL, "
						+ " \"win\" INT NOT NULL, " + " \"lose\" INT NOT NULL, " + " \"escape\" INT NOT NULL)";
				statement.executeUpdate(sql);
				statement.close();
				connection.close();
			}

		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	@Override
	public List<Player> getPlayerList() {
		try {
			Connection connection = DriverManager.getConnection(this.getConnectionString());
			connection.setAutoCommit(false);
			Statement statement = connection.createStatement();
			String sql = "SELECT * FROM \"player\";";
			ResultSet resultSet = statement.executeQuery(sql);
			List<Player> list = new ArrayList<Player>();
			while (resultSet.next()) {
				Player player = new Player();
				player.setId(resultSet.getInt("id"));
				player.setNickName(resultSet.getString("nickName"));
				player.setExperience(resultSet.getInt("experience"));
				player.setWin(resultSet.getInt("win"));
				player.setLose(resultSet.getInt("lose"));
				player.setEscape(resultSet.getInt("escape"));
				list.add(player);
			}
			resultSet.close();
			statement.close();
			connection.close();
			return list;
		} catch (Exception exception) {
			exception.printStackTrace();
			return null;
		}
	}

	@Override
	public Player getPlayerById(int id) {
		try {
			Connection connection = DriverManager.getConnection(this.getConnectionString());
			connection.setAutoCommit(false);
			String sql = "SELECT * FROM \"player\" WHERE \"id\" = ?;";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, id);
			ResultSet resultSet = statement.executeQuery();
			Player player = null;
			if (resultSet.next()) {
				player = new Player();
				player.setId(resultSet.getInt("id"));
				player.setNickName(resultSet.getString("nickName"));
				player.setExperience(resultSet.getInt("experience"));
				player.setWin(resultSet.getInt("win"));
				player.setLose(resultSet.getInt("lose"));
				player.setEscape(resultSet.getInt("escape"));
			}
			resultSet.close();
			statement.close();
			connection.close();
			return player;
		} catch (Exception exception) {
			exception.printStackTrace();
			return null;
		}
	}

	@Override
	public boolean addPlayer(Player player) {
		try {
			Connection connection = DriverManager.getConnection(this.getConnectionString());
			connection.setAutoCommit(false);
			String sql = "INSERT INTO \"player\" (\"id\",\"nickName\",\"experience\",\"win\",\"lose\",\"escape\") VALUES (?,?,?,?,?,?);";
			PreparedStatement statement = connection.prepareStatement(sql);
			int i = 1;
			statement.setInt(i++, player.getId());
			statement.setString(i++, player.getNickName());
			statement.setInt(i++, player.getExperience());
			statement.setInt(i++, player.getWin());
			statement.setInt(i++, player.getLose());
			statement.setInt(i++, player.getEscape());
			boolean result = (statement.executeUpdate() == 1);
			connection.commit();
			statement.close();
			connection.close();
			return result;
		} catch (Exception exception) {
			exception.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean modifyPlayer(int id, Player newPlayer) {
		try {
			Connection connection = DriverManager.getConnection(this.getConnectionString());
			connection.setAutoCommit(false);
			String sql = "UPDATE \"player\" SET \"nickName\" = ?, \"experience\" = ?, \"win\" = ?, \"lose\" = ?, \"escape\" = ? WHERE \"id\" = ?;";
			PreparedStatement statement = connection.prepareStatement(sql);
			int i = 1;
			statement.setString(i++, newPlayer.getNickName());
			statement.setInt(i++, newPlayer.getExperience());
			statement.setInt(i++, newPlayer.getWin());
			statement.setInt(i++, newPlayer.getLose());
			statement.setInt(i++, newPlayer.getEscape());
			statement.setInt(i++, newPlayer.getId());
			boolean result = (statement.executeUpdate() == 1);
			connection.commit();
			statement.close();
			connection.close();
			return result;
		} catch (Exception exception) {
			exception.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean removePlayer(int id) {
		try {
			Connection connection = DriverManager.getConnection(this.getConnectionString());
			connection.setAutoCommit(false);
			String sql = "DELETE FROM \"player\" WHERE \"id\" = ?;";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, id);
			boolean result = (statement.executeUpdate() == 1);
			connection.commit();
			statement.close();
			connection.close();
			return result;
		} catch (Exception exception) {
			exception.printStackTrace();
			return false;
		}
	}

}
