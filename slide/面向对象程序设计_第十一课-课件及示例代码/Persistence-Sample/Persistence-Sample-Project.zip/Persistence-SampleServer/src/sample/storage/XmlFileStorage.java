package sample.storage;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sample.api.model.Player;

public class XmlFileStorage implements Storage {
	private static Logger LOGGER = LoggerFactory.getLogger(XmlFileStorage.class);
	private String location;

	private String getLocation() {
		return location;
	}

	private void setLocation(String location) {
		this.location = location;
	}

	public XmlFileStorage() {
		try {
			this.setLocation((FilePath.getRootPath() + File.separator + "player.xml").replace('\\', '/'));
			LOGGER.info("Current file location is " + this.getLocation());
			File file = new File(this.getLocation());
			if (!file.exists()) {
				XMLEncoder xmlEncoder = new XMLEncoder(new FileOutputStream(file));
				xmlEncoder.writeObject(new ArrayList<Player>());
				xmlEncoder.close();
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Player> getPlayerList() {
		try {
			File file = new File(this.getLocation());
			XMLDecoder xmlDecoder = new XMLDecoder(new FileInputStream(file));
			List<Player> list = (List<Player>) xmlDecoder.readObject();
			xmlDecoder.close();
			return list;
		} catch (Exception exception) {
			exception.printStackTrace();
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Player getPlayerById(int id) {
		try {
			File file = new File(this.getLocation());
			XMLDecoder xmlDecoder = new XMLDecoder(new FileInputStream(file));
			List<Player> list = (List<Player>) xmlDecoder.readObject();
			xmlDecoder.close();
			for (Player player : list) {
				if (player.getId() == id) {
					return player;
				}
			}
			return null;
		} catch (Exception exception) {
			exception.printStackTrace();
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean addPlayer(Player player) {
		try {
			File file = new File(this.getLocation());
			XMLDecoder xmlDecoder = new XMLDecoder(new FileInputStream(file));
			List<Player> list = (List<Player>) xmlDecoder.readObject();
			xmlDecoder.close();
			for (Player exist : list) {
				if (exist.getId() == player.getId()) {
					return false;
				}
			}
			list.add(player);
			XMLEncoder xmlEncoder = new XMLEncoder(new FileOutputStream(file));
			xmlEncoder.writeObject(list);
			xmlEncoder.close();
			return true;
		} catch (Exception exception) {
			exception.printStackTrace();
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean modifyPlayer(int id, Player newPlayer) {
		try {
			File file = new File(this.getLocation());
			XMLDecoder xmlDecoder = new XMLDecoder(new FileInputStream(file));
			List<Player> list = (List<Player>) xmlDecoder.readObject();
			xmlDecoder.close();
			for (Player toModify : list) {
				if (toModify.getId() == id) {
					toModify.setEscape(newPlayer.getEscape());
					toModify.setExperience(newPlayer.getExperience());
					toModify.setLose(newPlayer.getLose());
					toModify.setNickName(newPlayer.getNickName());
					toModify.setWin(newPlayer.getWin());
					XMLEncoder xmlEncoder = new XMLEncoder(new FileOutputStream(file));
					xmlEncoder.writeObject(list);
					xmlEncoder.close();
					return true;
				}
			}
			return false;
		} catch (Exception exception) {
			exception.printStackTrace();
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean removePlayer(int id) {
		try {
			File file = new File(this.getLocation());
			XMLDecoder xmlDecoder = new XMLDecoder(new FileInputStream(file));
			List<Player> list = (List<Player>) xmlDecoder.readObject();
			xmlDecoder.close();
			Player toRemove = null;
			for (Player player : list) {
				if (player.getId() == id) {
					toRemove = player;
					break;
				}
			}
			if (toRemove == null) {
				return false;
			}
			list.remove(toRemove);
			XMLEncoder xmlEncoder = new XMLEncoder(new FileOutputStream(file));
			xmlEncoder.writeObject(list);
			xmlEncoder.close();
			return true;
		} catch (Exception exception) {
			exception.printStackTrace();
			return false;
		}
	}

}
