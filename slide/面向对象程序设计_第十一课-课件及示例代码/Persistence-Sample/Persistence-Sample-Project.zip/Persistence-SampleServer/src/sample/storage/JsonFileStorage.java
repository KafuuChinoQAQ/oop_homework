package sample.storage;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import sample.api.model.Player;

public class JsonFileStorage implements Storage {
	private static Logger LOGGER = LoggerFactory.getLogger(JsonFileStorage.class);
	private ObjectMapper objectMapper;
	private String location;

	private ObjectMapper getObjectMapper() {
		return objectMapper;
	}

	private void setObjectMapper(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}

	private String getLocation() {
		return location;
	}

	private void setLocation(String location) {
		this.location = location;
	}

	public JsonFileStorage() {
		try {
			this.setObjectMapper(new ObjectMapper());
			this.setLocation((FilePath.getRootPath() + File.separator + "player.json").replace('\\', '/'));
			LOGGER.info("Current file location is " + this.getLocation());
			File file = new File(this.getLocation());
			if (!file.exists()) {
				this.getObjectMapper().writeValue(new File(this.getLocation()), new ArrayList<Player>());
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	@Override
	public List<Player> getPlayerList() {
		try {
			return this.getObjectMapper().readValue(new File(this.getLocation()), new TypeReference<List<Player>>() {
			});
		} catch (Exception exception) {
			exception.printStackTrace();
			return null;
		}
	}

	@Override
	public Player getPlayerById(int id) {
		try {
			List<Player> list = this.getObjectMapper().readValue(new File(this.getLocation()),
					new TypeReference<List<Player>>() {
					});
			for (Player player : list) {
				if (player.getId() == id) {
					return player;
				}
			}
			return null;
		} catch (Exception exception) {
			exception.printStackTrace();
			return null;
		}
	}

	@Override
	public boolean addPlayer(Player player) {
		try {
			List<Player> list = this.getObjectMapper().readValue(new File(this.getLocation()),
					new TypeReference<List<Player>>() {
					});
			for (Player exist : list) {
				if (exist.getId() == player.getId()) {
					return false;
				}
			}
			list.add(player);
			this.getObjectMapper().writeValue(new File(this.getLocation()), list);
			return true;
		} catch (Exception exception) {
			exception.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean modifyPlayer(int id, Player newPlayer) {
		try {
			List<Player> list = this.getObjectMapper().readValue(new File(this.getLocation()),
					new TypeReference<List<Player>>() {
					});
			for (Player toModify : list) {
				if (toModify.getId() == id) {
					toModify.setEscape(newPlayer.getEscape());
					toModify.setExperience(newPlayer.getExperience());
					toModify.setLose(newPlayer.getLose());
					toModify.setNickName(newPlayer.getNickName());
					toModify.setWin(newPlayer.getWin());
					this.getObjectMapper().writeValue(new File(this.getLocation()), list);
					return true;
				}
			}
			return false;
		} catch (Exception exception) {
			exception.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean removePlayer(int id) {
		try {
			List<Player> list = this.getObjectMapper().readValue(new File(this.getLocation()),
					new TypeReference<List<Player>>() {
					});
			Player toRemove = null;
			for (Player player : list) {
				if (player.getId() == id) {
					toRemove = player;
					break;
				}
			}
			if (toRemove == null) {
				return false;
			}
			list.remove(toRemove);
			this.getObjectMapper().writeValue(new File(this.getLocation()), list);
			return true;
		} catch (Exception exception) {
			exception.printStackTrace();
			return false;
		}
	}

}
