package sample.storage;

import java.io.File;
import java.net.URL;

import sample.server.Main;

public final class FilePath {
	public static final String getRootPath() {
		URL url = Main.class.getProtectionDomain().getCodeSource().getLocation();
		String filePath = null;
		try {
			filePath = java.net.URLDecoder.decode(url.getPath(), "utf-8");
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (filePath.endsWith(".jar")) {
			filePath = filePath.substring(0, filePath.lastIndexOf("/") + 1);
		}
		File file = new File(filePath);
		return file.getAbsolutePath();
	}
}
