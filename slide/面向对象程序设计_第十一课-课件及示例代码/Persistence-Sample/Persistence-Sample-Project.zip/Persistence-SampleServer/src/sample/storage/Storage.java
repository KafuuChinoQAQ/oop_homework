package sample.storage;

import java.util.List;

import sample.api.model.Player;

public interface Storage {
	public List<Player> getPlayerList();

	public Player getPlayerById(int id);

	public boolean addPlayer(Player player);

	public boolean modifyPlayer(int id, Player newPlayer);

	public boolean removePlayer(int id);
}
