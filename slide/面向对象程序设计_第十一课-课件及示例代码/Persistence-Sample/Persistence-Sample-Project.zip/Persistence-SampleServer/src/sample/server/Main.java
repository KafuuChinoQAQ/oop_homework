package sample.server;

import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Main {
	private static Logger LOGGER = LoggerFactory.getLogger(Main.class);

	public static void main(String[] args) {
		try {
			LOGGER.trace("main(): enter function.");
			Properties configProperties = new Properties();
			InputStream configInputStream = Main.class.getResourceAsStream("/config.properties");
			configProperties.load(configInputStream);
			int port = Integer.valueOf(configProperties.getProperty("service.port"));

			StandaloneServer standaloneServer = new StandaloneServer(port);
			Runtime.getRuntime().addShutdownHook(new ShutdownHandler(standaloneServer));
			standaloneServer.start();
			LOGGER.trace("main(): exit function.");
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}
}
