package sample.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import sample.api.model.Player;
import sample.storage.Storage;
import sample.storage.StorageProvider;

@RestController
@CrossOrigin(origins = { "*" }, methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
		RequestMethod.DELETE })
public class PlayerController {
	private Storage storage;

	@Autowired
	public PlayerController(StorageProvider storageProvider) {
		this.storage= storageProvider.getStorage();
	}

	@RequestMapping(value = { "/Player" }, method = { RequestMethod.GET })
	public List<Player> list() {
		return this.storage.getPlayerList();
	}

	@RequestMapping(value = { "/Player/{id}" }, method = { RequestMethod.GET })
	public Player get(@PathVariable("id") int id) {
		return this.storage.getPlayerById(id);
	}

	@RequestMapping(value = { "/Player" }, method = { RequestMethod.POST }, consumes = "application/json")
	public boolean post(@RequestBody Player player) {
		return this.storage.addPlayer(player);
	}

	@RequestMapping(value = { "/Player/{id}" }, method = { RequestMethod.PUT }, consumes = "application/json")
	public boolean put(@PathVariable("id") int id, @RequestBody Player newPlayer) {
		return this.storage.modifyPlayer(id, newPlayer);
	}

	@RequestMapping(value = { "/Player/{id}" }, method = { RequestMethod.DELETE })
	public boolean delete(@PathVariable("id") int id) {
		return this.storage.removePlayer(id);
	}
}
